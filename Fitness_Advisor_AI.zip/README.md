
  # Fitness_Advisor_AI

  This is a code bundle for Fitness_Advisor_AI. The original project is available at https://www.figma.com/design/ZhqHybJj8BQl9GtFINIf29/Fitness_Advisor_AI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  